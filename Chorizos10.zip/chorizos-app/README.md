# Chorizos — panel de ventas

Aplicación web estática para GitHub Pages. Permite gestionar inventario de packs x5 y x7, lotes, clientes, entrega y estado de pago.

## Publicar en GitHub Pages
1. Sube `index.html`, `styles.css`, `app.js`, `manifest.json` y `sw.js` a la raíz del repositorio.
2. En GitHub abre **Settings → Pages**.
3. En **Build and deployment**, selecciona **Deploy from a branch**, elige `main` y la carpeta `/ (root)`, y guarda.
4. Abre la URL que GitHub Pages indique. Para instalarla como app, ábrela desde el navegador compatible y usa la opción de instalar/añadir a pantalla de inicio.

## Funcionamiento
- Precios: pack x5 = $17.000 COP; pack x7 = $22.000 COP.
- El inventario se comparte entre lotes; los clientes y ventas se separan por lote.
- Al crear o editar pedidos, el inventario se ajusta por diferencia. Al eliminar un pedido, los packs se devuelven al inventario.
- Los datos se guardan en el almacenamiento local del navegador (`localStorage`); no se sincronizan entre dispositivos ni usuarios. Borra los datos del sitio solo si entiendes que perderás los registros locales.
- Esta versión no tiene servidor ni copias de seguridad automáticas. Exporta o respalda los datos antes de cambiar de navegador o dispositivo.
